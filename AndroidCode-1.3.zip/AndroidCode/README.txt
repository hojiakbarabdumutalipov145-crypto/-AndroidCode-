ANDROID CODE - Android loyihasi

APK qilib yig'ish:
1. Android Studio'ni o'rnating (developer.android.com/studio).
2. File > Open orqali shu papkani (KodMuharriri) oching.
3. Gradle sync tugashini kuting (birinchi marta bir necha daqiqa va internet kerak).
   Agar "Update Gradle/AGP" taklifi chiqsa, "Update" ni bosing yoki rad eting - ikkalasi ham bo'ladi.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Tayyor fayl: app/build/outputs/apk/debug/app-debug.apk

Telefonga o'rnatish:
- app-debug.apk faylini telefonga ko'chiring (kabel, Telegram yoki Drive orqali).
- Faylni oching va "Noma'lum manbalardan o'rnatishga" ruxsat bering.

Muharrir kodi: app/src/main/assets/index.html
Dastur nomi: app/src/main/res/values/strings.xml

YANGILIKLAR (1.1):
- Dastur nomi: Android code
- <div> yozib > bosilganda </div> avtomatik chiqadi (HTML). </ yozilsa ochiq teg o'zi yopiladi, = bosilsa "" chiqadi.
- Harf yozilganda takliflar ro'yxati chiqadi (HTML, CSS, JS, TS, Python). Tab yoki ro'yxatga bosib tanlanadi.
  Sozlamalar bo'limidan "Avtotoldirish"ni o'chirib qo'yish mumkin.
- Eski versiya ustiga o'rnatilganda fayllar saqlanib qoladi (applicationId o'zgarmagan).

YANGILIKLAR (1.2):
- Ko'p tilli: PHP, Java, Kotlin, C/C++, C#, Go, Rust, Ruby, SQL, Shell, YAML, Swift, Dart, Lua, INI/TOML - ranglar va takliflar.
  (PHP va boshqa tillar telefonda ishga tushmaydi, faqat tahrirlanadi.)
- HTML ichidagi <style> va <script> kodi ham ranglanadi; ranglar yaxshilandi.
- Papka ochish (VS Code kabi): yangi fayl yaratish, nomini o'zgartirish, o'chirish - hammasi papkaga saqlanadi.
- Natija to'liq ekranda ochiladi; "Brauzerda ochish" - Live Server kabi (127.0.0.1).

YANGILIKLAR (1.3):
- Rasm, video va audio: ochilgan papkadagi mediafayllar (png, jpg, gif, webp, mp4, webm, mp3, wav, ogg ...) fayllar ro'yxatida chiqadi va bosilganda ko'rinadi/eshitiladi.
- HTML natijasida <img>, <video>, <audio>, <source> va CSS'dagi url(...) papkadagi fayllarni ishlatadi (katta fayllar ham, video oldinga-orqaga suriladi).
- Natija ichidagi media havolasi (<a href="qo'shiq.mp3">) bosilsa, ko'rish oynasi ochiladi.
- Video to'liq ekranga chiqadi. Media ham "Brauzerda ochish" orqali ochiladi.
- Eslatma: JS ichidan yuklanadigan media (masalan new Audio('a.mp3')) faqat "Brauzerda ochish"da ishlaydi.
