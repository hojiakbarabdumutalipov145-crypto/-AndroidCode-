package uz.kodmuharriri

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

/**
 * JS ("window.AndroidBridge") bilan Android o'rtasidagi ko'prik.
 * Har bir chaqiruv birinchi argument sifatida sessiya kalitini (token) talab qiladi,
 * shuning uchun natija oynasidagi (iframe) begona kod bu metodlardan foydalana olmaydi.
 */
class Bridge(private val act: MainActivity) {

    private val server = LocalServer(act)
    private val skipDirs = setOf(".git", "node_modules", "build", ".gradle", ".idea", "__pycache__", ".cache", "dist")

    private fun ok(t: String?): Boolean = t != null && t == act.token

    @JavascriptInterface
    fun pickFolder(t: String) {
        if (!ok(t)) return
        act.runOnUiThread { act.launchFolderPicker() }
    }

    @JavascriptInterface
    fun listFolder(t: String, treeUri: String): String {
        if (!ok(t)) return "[]"
        val out = JSONArray()
        try {
            val root = DocumentFile.fromTreeUri(act, Uri.parse(treeUri))
            if (root != null) walk(root, "", 0, out)
        } catch (e: Exception) {
            // bo'sh ro'yxat qaytadi
        }
        return out.toString()
    }

    private fun walk(dir: DocumentFile, prefix: String, depth: Int, out: JSONArray) {
        if (depth > 8) return
        for (f in dir.listFiles()) {
            if (out.length() >= 2000) return
            val name = f.name ?: continue
            if (f.isDirectory) {
                if (name in skipDirs) continue
                walk(f, prefix + name + "/", depth + 1, out)
            } else {
                val o = JSONObject()
                o.put("p", prefix + name)
                o.put("u", f.uri.toString())
                o.put("s", f.length())
                out.put(o)
            }
        }
    }

    @JavascriptInterface
    fun readText(t: String, uri: String): String? {
        if (!ok(t)) return null
        return try {
            act.contentResolver.openInputStream(Uri.parse(uri))?.use { String(it.readBytes(), Charsets.UTF_8) }
        } catch (e: Exception) {
            null
        }
    }

    private fun writeUri(uri: Uri, text: String): Boolean {
        return try {
            val os = act.contentResolver.openOutputStream(uri, "wt") ?: return false
            os.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun writeText(t: String, uri: String, text: String): Boolean {
        if (!ok(t)) return false
        return writeUri(Uri.parse(uri), text)
    }

    @JavascriptInterface
    fun createFile(t: String, treeUri: String, rel: String, text: String): String? {
        if (!ok(t)) return null
        return try {
            val root = DocumentFile.fromTreeUri(act, Uri.parse(treeUri)) ?: return null
            val parts = rel.split("/").filter { it.isNotEmpty() }
            if (parts.isEmpty() || parts.any { it == ".." || it == "." }) return null
            var dir: DocumentFile = root
            for (i in 0 until parts.size - 1) {
                val next = dir.findFile(parts[i])
                dir = if (next != null && next.isDirectory) next else (dir.createDirectory(parts[i]) ?: return null)
            }
            val name = parts[parts.size - 1]
            var f = dir.findFile(name)
            if (f == null) f = dir.createFile("application/octet-stream", name)
            if (f == null) return null
            if (!writeUri(f.uri, text)) return null
            f.uri.toString()
        } catch (e: Exception) {
            null
        }
    }

    @JavascriptInterface
    fun deleteFile(t: String, uri: String): Boolean {
        if (!ok(t)) return false
        return try {
            DocumentsContract.deleteDocument(act.contentResolver, Uri.parse(uri))
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun saveAs(t: String, name: String, text: String): Boolean {
        if (!ok(t)) return false
        act.runOnUiThread { act.launchSave(name, text) }
        return true
    }

    @JavascriptInterface
    fun serveProject(t: String, json: String) {
        if (!ok(t)) return
        try {
            val o = JSONObject(json)
            val fo = o.getJSONObject("files")
            val m = HashMap<String, String>()
            val keys = fo.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                m[k] = fo.getString(k)
            }
            server.files = m
            server.rootUri = o.optString("root", "")
        } catch (e: Exception) {
            // eski holat qoladi
        }
    }

    /** Mahalliy serverni ishga tushiradi va manzilini qaytaradi (rasm/video/audio uchun). */
    @JavascriptInterface
    fun mediaBase(t: String): String? {
        if (!ok(t)) return null
        return try {
            val port = server.start()
            if (port <= 0) null else "http://127.0.0.1:" + port
        } catch (e: Exception) {
            null
        }
    }

    @JavascriptInterface
    fun openInBrowser(t: String, path: String): Boolean {
        if (!ok(t)) return false
        return try {
            val port = server.start()
            if (port <= 0) return false
            val enc = path.split("/").joinToString("/") { Uri.encode(it) }
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://127.0.0.1:" + port + "/" + enc))
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            act.runOnUiThread {
                try {
                    act.startActivity(i)
                } catch (e: ActivityNotFoundException) {
                    // brauzer topilmadi
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun openUrl(t: String, url: String) {
        if (!ok(t)) return
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        act.runOnUiThread {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: Exception) {
                // brauzer topilmadi
            }
        }
    }

    @JavascriptInterface
    fun readDataUrl(t: String, treeUri: String, rel: String): String? {
        if (!ok(t)) return null
        return try {
            val f = resolveDoc(act, treeUri, rel) ?: return null
            if (f.isDirectory || f.length() > 3000000L) return null
            val bytes = act.contentResolver.openInputStream(f.uri)?.use { it.readBytes() } ?: return null
            "data:" + LocalServer.mime(rel).substringBefore(';') + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }
}
