package uz.kodmuharriri

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

/** Papkadagi (tree uri) yoki xotiradagi fayl yo'lini DocumentFile'ga aylantiradi. */
fun resolveDoc(ctx: Context, treeUri: String, rel: String): DocumentFile? {
    var d: DocumentFile? = DocumentFile.fromTreeUri(ctx, Uri.parse(treeUri))
    for (seg in rel.split("/")) {
        if (seg.isEmpty() || seg == ".") continue
        if (seg == "..") return null
        d = d?.findFile(seg)
        if (d == null) return null
    }
    return d
}

/**
 * Faqat 127.0.0.1 da ishlaydigan kichik HTTP server (VS Code'dagi "Live Server" kabi).
 * Loyiha fayllari JS tomondan beriladi, rasm va boshqa fayllar tanlangan papkadan o'qiladi.
 */
class LocalServer(private val ctx: Context) {

    @Volatile
    var files: Map<String, String> = emptyMap()

    @Volatile
    var rootUri: String = ""

    private var socket: ServerSocket? = null

    @Synchronized
    fun start(): Int {
        val existing = socket
        if (existing != null && !existing.isClosed) return existing.localPort
        val addr = InetAddress.getByName("127.0.0.1")
        var s: ServerSocket? = null
        for (p in 8080..8090) {
            if (s == null) {
                try {
                    s = ServerSocket(p, 20, addr)
                } catch (e: Exception) {
                    s = null
                }
            }
        }
        if (s == null) {
            try {
                s = ServerSocket(0, 20, addr)
            } catch (e: Exception) {
                s = null
            }
        }
        val server = s ?: return 0
        socket = server
        Thread {
            while (!server.isClosed) {
                try {
                    val c = server.accept()
                    Thread { handle(c) }.start()
                } catch (e: Exception) {
                    break
                }
            }
        }.start()
        return server.localPort
    }

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 10000
            val input = BufferedReader(InputStreamReader(c.getInputStream(), Charsets.ISO_8859_1))
            val line = input.readLine() ?: return
            var rangeHdr: String? = null
            while (true) {
                val h = input.readLine() ?: break
                if (h.isEmpty()) break
                if (h.startsWith("range:", ignoreCase = true)) rangeHdr = h.substring(6).trim()
            }
            val out = c.getOutputStream()
            val parts = line.split(" ")
            val head = parts.isNotEmpty() && parts[0] == "HEAD"
            if (parts.size < 2 || (parts[0] != "GET" && parts[0] != "HEAD")) {
                respond(out, 405, "text/plain", "405".toByteArray(), false)
                return
            }
            var path = parts[1]
            val q = path.indexOfAny(charArrayOf('?', '#'))
            if (q >= 0) path = path.substring(0, q)
            path = Uri.decode(path).trimStart('/')
            if (path.isEmpty() || path.endsWith("/")) path += "index.html"
            if (path.split("/").any { it == ".." }) {
                respond(out, 403, "text/plain", "403".toByteArray(), head)
                return
            }
            val src = find(path)
            if (src == null) {
                respond(out, 404, "text/plain; charset=utf-8", ("404: " + path).toByteArray(Charsets.UTF_8), head)
            } else {
                serve(out, src, mime(path), rangeHdr, head)
            }
        } catch (e: Exception) {
            // ulanish uzildi yoki o'qib bo'lmadi
        } finally {
            try {
                c.close()
            } catch (e: Exception) {
            }
        }
    }

    /** Berilayotgan fayl: xotiradagi matn yoki papkadagi fayl (rasm, video, audio...). */
    private class Src(val bytes: ByteArray?, val doc: DocumentFile?, val size: Long)

    private fun find(path: String): Src? {
        val t = files[path]
        if (t != null) {
            val b = t.toByteArray(Charsets.UTF_8)
            return Src(b, null, b.size.toLong())
        }
        val root = rootUri
        if (root.isEmpty()) return null
        var f = resolveDoc(ctx, root, path) ?: return null
        if (f.isDirectory) f = resolveDoc(ctx, root, "$path/index.html") ?: return null
        if (!f.isFile) return null
        return Src(null, f, f.length())
    }

    /** "Range: bytes=a-b" ni [boshi, oxiri] ga aylantiradi (video oldinga-orqaga surish uchun kerak). */
    private fun parseRange(h: String?, size: Long): LongArray? {
        if (h == null || !h.startsWith("bytes=") || size <= 0) return null
        val spec = h.substring(6).substringBefore(',').trim()
        val dash = spec.indexOf('-')
        if (dash < 0) return null
        val a = spec.substring(0, dash)
        val b = spec.substring(dash + 1)
        val start: Long
        var end: Long
        if (a.isEmpty()) {
            val n = b.toLongOrNull() ?: return null
            if (n <= 0) return null
            start = maxOf(0L, size - n)
            end = size - 1
        } else {
            start = a.toLongOrNull() ?: return null
            end = if (b.isEmpty()) size - 1 else (b.toLongOrNull() ?: return null)
        }
        if (end >= size) end = size - 1
        if (start < 0 || start > end) return null
        return longArrayOf(start, end)
    }

    private fun serve(out: OutputStream, src: Src, type: String, rangeHdr: String?, head: Boolean) {
        val total = src.size
        val r = parseRange(rangeHdr, total)
        val start = if (r != null) r[0] else 0L
        val end = if (r != null) r[1] else total - 1
        val len = if (total <= 0L) 0L else end - start + 1
        val sb = StringBuilder()
        sb.append(if (r != null) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n")
        sb.append("Content-Type: ").append(type).append("\r\n")
        sb.append("Accept-Ranges: bytes\r\n")
        sb.append("Content-Length: ").append(len).append("\r\n")
        if (r != null) sb.append("Content-Range: bytes ").append(start).append('-').append(end).append('/').append(total).append("\r\n")
        sb.append("Access-Control-Allow-Origin: *\r\n")
        sb.append("Cache-Control: no-store\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        if (!head && len > 0) {
            val bytes = src.bytes
            if (bytes != null) {
                out.write(bytes, start.toInt(), len.toInt())
            } else {
                val doc = src.doc ?: return
                ctx.contentResolver.openInputStream(doc.uri)?.use { ins ->
                    var skip = start
                    while (skip > 0) {
                        val n = ins.skip(skip)
                        if (n <= 0) break
                        skip -= n
                    }
                    val buf = ByteArray(65536)
                    var left = len
                    while (left > 0) {
                        val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        out.write(buf, 0, n)
                        left -= n
                    }
                }
            }
        }
        out.flush()
    }

    private fun respond(out: OutputStream, code: Int, type: String, body: ByteArray, head: Boolean) {
        val status = when (code) {
            200 -> "OK"
            403 -> "Forbidden"
            404 -> "Not Found"
            else -> "Method Not Allowed"
        }
        val header = "HTTP/1.1 " + code + " " + status + "\r\n" +
            "Content-Type: " + type + "\r\n" +
            "Content-Length: " + body.size + "\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.ISO_8859_1))
        if (!head) out.write(body)
        out.flush()
    }

    companion object {
        fun mime(path: String): String {
            val ext = path.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "html", "htm" -> "text/html; charset=utf-8"
                "css" -> "text/css; charset=utf-8"
                "js", "mjs" -> "application/javascript; charset=utf-8"
                "json" -> "application/json; charset=utf-8"
                "svg" -> "image/svg+xml"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                "ico" -> "image/x-icon"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                "ttf" -> "font/ttf"
                "bmp" -> "image/bmp"
                "avif" -> "image/avif"
                "mp4", "m4v" -> "video/mp4"
                "webm" -> "video/webm"
                "mkv" -> "video/x-matroska"
                "mov" -> "video/quicktime"
                "3gp" -> "video/3gpp"
                "mp3" -> "audio/mpeg"
                "wav" -> "audio/wav"
                "ogg", "oga", "opus" -> "audio/ogg"
                "m4a" -> "audio/mp4"
                "aac" -> "audio/aac"
                "flac" -> "audio/flac"
                "pdf" -> "application/pdf"
                "txt", "md" -> "text/plain; charset=utf-8"
                "xml" -> "application/xml; charset=utf-8"
                else -> "application/octet-stream"
            }
        }
    }
}
