package uz.kodmuharriri

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // Videoni to'liq ekranga chiqarish uchun
    private var fsView: View? = null
    private var fsCallback: WebChromeClient.CustomViewCallback? = null

    private fun exitFullscreenVideo() {
        val v = fsView ?: return
        (window.decorView as ViewGroup).removeView(v)
        fsView = null
        fsCallback?.onCustomViewHidden()
        fsCallback = null
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    // Har bir ishga tushirishda yangi kalit: faqat asosiy sahifa ko'prikdan foydalana oladi
    val token: String = UUID.randomUUID().toString()
    private var pendingSave: String = ""

    // Telefondagi papkani tanlash (VS Code'dagi "Open Folder")
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        onFolderPicked(uri)
    }

    // Faylni "Boshqa nom bilan saqlash"
    private val saver = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(pendingSave.toByteArray(Charsets.UTF_8)) }
                callJs("window.__toast && window.__toast('Сақланди')")
            } catch (e: Exception) {
                callJs("window.__toast && window.__toast('Сақлаб бўлмади')")
            }
        }
    }

    fun launchFolderPicker() {
        folderPicker.launch(null)
    }

    fun launchSave(name: String, text: String) {
        pendingSave = text
        saver.launch(name)
    }

    fun callJs(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun onFolderPicked(uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            // ruxsat saqlanmasa ham ishlayveradi (shu ishga tushirish davomida)
        }
        val name = DocumentFile.fromTreeUri(this, uri)?.name ?: "Папка"
        callJs("window.__folderPicked && window.__folderPicked(" + JSONObject.quote(uri.toString()) + "," + JSONObject.quote(name) + ")")
    }

    // Qurilmadan fayl tanlash (muharrirdagi "Qurilmadan fayl ochish" tugmasi)
    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        var uris: Array<Uri>? = null
        if (res.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            uris = when {
                clip != null -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
        }
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        // Fayllar https://appassets.androidplatform.net manzilidan beriladi,
        // shunda localStorage va Web Worker odatdagi saytdagidek ishlaydi.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            textZoom = 100
            // natija oynasi (https) 127.0.0.1 dagi rasm/video/audioni yuklay olishi uchun
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                if (url != null && url.startsWith("https://appassets.androidplatform.net")) {
                    view.evaluateJavascript(
                        "window.__AB_TOK=" + JSONObject.quote(token) + ";if(window.__abReady)window.__abReady();",
                        null
                    )
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, url))
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (fsView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                fsView = view
                fsCallback = callback
                (window.decorView as ViewGroup).addView(
                    view,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
            }

            override fun onHideCustomView() {
                exitFullscreenVideo()
            }

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    picker.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(this), "AndroidBridge")

        // Orqaga tugmasi: avval natija oynasini yopadi, keyin ilovadan chiqadi
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fsView != null) {
                    exitFullscreenVideo()
                    return
                }
                web.evaluateJavascript("(function(){return !!(window.__onBack && window.__onBack());})()") { r ->
                    if (r != "true") {
                        isEnabled = false
                        this@MainActivity.onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState)
        } else {
            web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
